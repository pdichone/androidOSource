
fun main(args: Array<String>) {
    /*
       Addition (+)
       Subtraction (-)
       Multiplication(*)
     */

    var firstNum = 5
    var secondNum = 15

    //var result:Int?

    // result = firstNum + secondNum

    println("The result is ${firstNum - secondNum }")



}
