fun main(args: Array<String>) {
    /*
       Read input
     */

    println("============================")
    println(" ->Welcome to our Store<-")
    println("============================")

    println("Hello! What can we do for you?")
    var customerResponse = readLine()

    println("Yes, indeed.  We have fresh bread off the oven!  " +
            "It's your lucky day!")

    var customerSecondResponse = readLine()

    println("You are very welcome!  Have a nice day!")


    println("================== ====================")
    println("================== ====================")

    println("Your Conversation with the Clerk")

    println("Clerk: Hello! What can we do for you?")
    println("Customer: $customerResponse")

    println("Clerk: Yes, indeed.  We have fresh bread off the oven!  " +
            "It's your lucky day!")

    println("Customer: $customerSecondResponse")

    println("Clerk: You are very welcome!  Have a nice day!")










    //println(customerResponse)
}
