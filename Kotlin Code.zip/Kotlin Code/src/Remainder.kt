
fun main(args: Array<String>) {
    /*
       Addition (+)
       Subtraction (-)
       Multiplication(*)
       Division (/)
       Remainder (%) "what remains after dividing two numbers"
       Increment +

     */

//    var firstNum:Float = 1.0f
//    var secondNum:Float = 5.0f

    var firstNum = 8
    var secondNum = 3
    // 4/2 = 2 ==> remainder 0
    //var result:Int?

    // result = firstNum + secondNum

    println("The result is ${firstNum % secondNum }")



}
