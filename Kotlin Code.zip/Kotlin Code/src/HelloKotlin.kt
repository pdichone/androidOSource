
fun main(args: Array<String>) {

    // This will print a message
    /*

    */
     println("Hello Kotlin")
     println("I love Kotlin")



}