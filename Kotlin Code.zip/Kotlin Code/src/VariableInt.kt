fun main(args: Array<String>) {

    /*
       Variables = a little bucket where we can put information
       Types: String, Int, Double, Boolean, Float, Char
       String;
       Int = number
     */

    var name:String? = null
   // name = "James"
     var age = 31 // we are implicitly defining age to be an Integer Type
     var myAge:Int = 32

    println("$name is $age" )

}