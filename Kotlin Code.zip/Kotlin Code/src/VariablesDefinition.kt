
fun main(args: Array<String>) {

    /*
       Variables = a little bucket where we can put information
     */
    var name = "Paulo"
    var lastName = "Dichone"
    var dogName = "Dufus"

    println(name + " " +lastName + " has a dog named: " +
       dogName)
    println(lastName)
    println(dogName)
}