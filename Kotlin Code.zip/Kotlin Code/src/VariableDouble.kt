fun main(args: Array<String>) {

    /*
       Variables = a little bucket where we can put information
       Types: String, Int, Double, Boolean, Float, Char
       String;
       Int = number
       Double type 23.00, 21.89
     */

    var myDouble = 23.01
    var newDouble: Double? = null

    newDouble = 23.0


    println("Here's my number $newDouble")


}
