
fun main(args: Array<String>) {
    /*
       Addition (+)
       Subtraction (-)
       Multiplication(*)
       Division (/)

     */

    var firstNum = 5
    var secondNum = 1

    //var result:Int?

    // result = firstNum + secondNum

    println("The result is ${firstNum * secondNum }")



}
