fun main(args: Array<String>) {
    //Do-While Loop - it at least runs once
    var counter = 1

    do {

        if (counter % 3 == 0) println("Fizz") else println("Buzz")


        counter++

    }while (counter < 15)


}
