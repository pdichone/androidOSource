
fun main(args: Array<String>) {
    /*
       Addition (+)
       Subtraction (-)
       Multiplication(*)
       Division (/)
       Remainder (%) "what remains after dividing two numbers

     */

//    var firstNum:Float = 1.0f
//    var secondNum:Float = 5.0f

    var firstNum = 1
    var secondNum = 5
    //var result:Int?

    // result = firstNum + secondNum

    println("The result is ${firstNum / secondNum.toFloat() }")



}
